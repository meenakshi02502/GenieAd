document.getElementById("generateBtn").addEventListener("click", function() {
  const input = document.getElementById("userInput").value.trim();
  const outputDiv = document.getElementById("output");

  if (!input) {
    outputDiv.innerHTML = "⚠️ Please enter a product or idea!";
    return;
  }

  // 🔮 Define word variations for creativity
  const adjectives = ["revolutionary", "next-gen", "eco-smart", "luxurious", "innovative", "stylish", "intelligent", "futuristic", "vibrant", "crafted-to-perfection"];
  const actions = [
    "redefines what’s possible",
    "makes everyday life extraordinary",
    "brings elegance to your fingertips",
    "blends design and performance beautifully",
    "turns imagination into reality",
    "inspires every moment",
    "transforms your lifestyle",
    "empowers your creativity",
    "adds a spark of magic to your day",
    "is engineered to amaze"
  ];
  const endings = [
    "because you deserve the extraordinary.",
    "for dreamers who make things happen.",
    "crafted with passion and precision.",
    "built for those who think different.",
    "where imagination meets purpose.",
    "because brilliance begins here.",
    "for minds that dare to stand out."
  ];

  // ✨ Generate random parts
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const action = actions[Math.floor(Math.random() * actions.length)];
  const end = endings[Math.floor(Math.random() * endings.length)];

  // 🎯 Generate final creative ad
  const ad = `
    <div style="font-size:1.2rem;line-height:1.6;">
      🚀 Introducing the <strong>${adj}</strong> <em>${input}</em> — it ${action}, ${end}
    </div>
  `;

  // 🪩 Add a smooth reveal animation
  outputDiv.innerHTML = ad;
  outputDiv.style.opacity = 0;
  setTimeout(() => { outputDiv.style.transition = "opacity 1s"; outputDiv.style.opacity = 1; }, 50);
});
